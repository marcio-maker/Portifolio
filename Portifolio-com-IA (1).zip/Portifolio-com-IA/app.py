from flask import Flask, render_template, request, jsonify
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = "dev_key_123"

# Static projects data
PROJECTS = [
    {
        "title": "Projeto Web",
        "description": "Desenvolvimento de um site responsivo usando HTML, CSS e JavaScript",
        "image_icon": "fas fa-globe",
        "link": "https://github.com"
    },
    {
        "title": "Aplicação Python",
        "description": "Sistema de automação desenvolvido com Python",
        "image_icon": "fab fa-python",
        "link": "https://github.com"
    },
    {
        "title": "App Mobile",
        "description": "Aplicativo mobile desenvolvido com React Native",
        "image_icon": "fas fa-mobile-alt",
        "link": "https://github.com"
    }
]

@app.route('/')
def index():
    return render_template('index.html', projects=PROJECTS)

@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    if request.method == 'POST':
        try:
            # Here you could add email sending functionality in the future
            logger.info(f"Contact form submission from {request.form.get('name')} ({request.form.get('email')})")
            return jsonify({'status': 'success'})
        except Exception as e:
            logger.error(f"Error processing contact form: {str(e)}")
            return jsonify({'status': 'error', 'message': 'Erro ao processar formulário'}), 500

    return jsonify({'status': 'error'}), 400