# Portfólio Profissional

Portfólio profissional moderno desenvolvido com Flask e JavaScript, oferecendo uma experiência de usuário dinâmica e responsiva.

## Tecnologias Utilizadas

- Flask (Backend)
- JavaScript (Frontend interativo)
- HTML5/CSS3
- Bootstrap 5
- Design Responsivo

## Funcionalidades

- Página inicial com seções:
  - Hero section com apresentação
  - Sobre mim
  - Habilidades técnicas
  - Projetos
  - Formulário de contato
- Design responsivo para todos os dispositivos
- Animações suaves para melhor experiência do usuário
- Integração de ícones Font Awesome
- Sistema de contato funcional

## Como Executar

1. Clone o repositório:
```bash
git clone <seu-repositorio>
cd <nome-do-diretorio>
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Execute o projeto:
```bash
python main.py
```

O site estará disponível em `http://localhost:5000`

## Estrutura do Projeto

```
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── templates/
│   ├── base.html
│   └── index.html
├── app.py
├── main.py
└── README.md
```

## Contribuindo

Sinta-se à vontade para fazer um fork do projeto e enviar suas contribuições através de pull requests.

## Licença

Este projeto está sob a licença MIT.
